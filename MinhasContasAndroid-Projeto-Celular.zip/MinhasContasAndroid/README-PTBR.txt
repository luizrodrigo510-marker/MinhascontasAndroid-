MINHAS CONTAS - PROJETO ANDROID

Este pacote transforma o arquivo HTML enviado em um aplicativo Android nativo (WebView), com os arquivos do app embarcados no APK.

O QUE FOI MANTIDO
- Cadastro, edição e exclusão de contas
- Marcar contas como pagas ou pendentes
- Filtro por situação
- Renda mensal, totais e saldo
- Salvamento local automático no armazenamento do WebView
- Importação de backup JSON pelo seletor de arquivos do Android
- Exportação de backup JSON pelo seletor de destino do Android

COMO GERAR O APK
1. Instale o Android Studio em um computador.
2. Abra a pasta MinhasContasAndroid no Android Studio (Open).
3. Aguarde a sincronização do Gradle e a instalação dos componentes solicitados (Android SDK 35).
4. No menu Build, escolha Build Bundle(s) / APK(s) > Build APK(s).
5. O Android Studio exibirá o caminho do APK gerado. Transfira-o para o celular e abra o arquivo para instalar. Talvez seja necessário autorizar a instalação de apps dessa origem.

OBSERVAÇÕES IMPORTANTES
- Este ambiente não possui Android SDK nem Gradle, portanto não foi possível compilar e validar um arquivo .APK aqui. O pacote entregue é o projeto Android pronto para abrir e compilar no Android Studio.
- Os dados ficam no armazenamento local deste aplicativo/aparelho. Desinstalar ou limpar os dados do app pode apagá-los; use Exportar backup.
- Os lembretes/notificações dependem do suporte do Android WebView e podem não funcionar como notificações agendadas quando o app estiver fechado. O restante do controle financeiro funciona localmente.
